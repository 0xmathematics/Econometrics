############################################################################
# Class demo on Linear Regression
############################################################################

############################################################################
library('readxl')
##############################
## Loading data
##############################
## load excel file
dtibble <- read_excel("cps08.xlsx", col_types = "numeric")
df = data.frame(dtibble)
head(df)
nrow(df)



### matrix method
y = df$ahe
X = df[ , c(3,4,5)]
n = nrow(df)
intercept = rep(1,nrow(df))
X = cbind(intercept,X)

X = as.matrix(X)
y = as.matrix(y)

betaOLS = solve( t(X) %*% X ) %*% t(X) %*% y

u_hat = y- X %*%betaOLS
SSR2 = sum(u_hat^2)
SSR2
SSR = t(y- X %*%betaOLS )%*% (y- X %*%betaOLS )
sigmasqaureHat = SSR/ (n-3-1)

sigmasqaureHat = as.numeric(sigmasqaureHat)

VarCovMatrixBetaOLS = sigmasqaureHat * solve(t(X) %*% X) 

VarBetaOLS = diag(VarCovMatrixBetaOLS)
sdBetaOLS = sqrt(VarBetaOLS)

# multiple regression
linearMod2 <- lm(ahe ~ bachelor+female+age, data=df)
summary(linearMod2) 
summary(linearMod2)$coef
betaOLS
sdBetaOLS

z = (8.0830009 - 5)/ 0.20881336
t = (8.0830009 - 5)/ 0.20881336

deg = n-3-1
qnorm(0.99)
qt(0.99, deg)

2.326348 
z
1- pnorm(z)
1- pt(t,deg)


beta1 = 8.0830009
threshold = qnorm(0.995)
sd_beta1 = 0.20881336

left = beta1- threshold * sd_beta1
right = beta1 + threshold* sd_beta1
CI99 = c(left,right)
CI99


